<?php
/**
     * Plugin Name: Met Ice Carousel
     * Description: Another Carousel No One Needs
     * Version: 1.0.0
     * Author: Met Ice
 */

// define const
define('UPDATE_URL', 'http://localhost/met-ice-carousel-update.json');      //json file location
define('PLUGIN_SLUG', 'met-ice-carousel');                                  //slug

// get plugin update
function miGetUpdate($transient){

    // check for transient obj - if missing create new
    if(!is_object($transient)) $transient = new stdClass();
    
    // end case - check for  
    if(empty($transient->checked)) return $transient;

    // get file 
    $file = plugin_basename(__FILE__);
    // $file = plugin_basename(WP_PLUGIN_DIR.'/met-ice-carousel/met-ice-carousel.php');

    // get file remotely
    $remote = wp_remote_get(UPDATE_URL);

    // check for errors - return
    if(is_wp_error($remote) || (wp_remote_retrieve_response_code($remote) !== 200)) return $transient;

    // get data
    $data = json_decode(wp_remote_retrieve_body($remote));



// DEBUG VERSION CHECK
error_log("REMOTE VERSION: " . print_r($data->version, true));
$version = $transient->checked[$file] ?? "0";
error_log("LOCAL VERSION: " . print_r($version, true));
error_log("VERSION COMPARE (<): " . (version_compare($version, $data->version, '<') ? 'YES' : 'NO'));


    // check version - return
    if(!isset($data->version)) return $transient;    


    // get version
    $version = $transient->checked[$file] ?? "0";

    // compare versions
    if(version_compare($version, $data->version, '<')){

        // response obj
        $transient->response[$file] = (object)[

            'id'            => PLUGIN_SLUG,
            'slug'          => PLUGIN_SLUG,
            'plugin'        => $file,

            // REQUIRED
            'name'          => 'Met Ice Carousel',
            'plugin_name'   => 'Met Ice Carousel',
            'version'       => $data->version,           // <-- REQUIRED
            'new_version'   => $data->version,
            'url'           => $data->homepage,
            'package'       => $data->url,

            // MUST be objects (NOT arrays)
            'icons'         => (object) [],
            'banners'       => (object) [],
            'banners_rtl'   => (object) [],

            // Required meta
            'requires'      => '5.0',
            'tested'        => '6.8',
            'requires_php'  => '7.4',

            // MUST be object
            'compatibility' => (object) [],

        ];

    }

error_log("UPDATE PACKAGE URL: " . $transient->response[$file]->package);
error_log("DOWNLOAD TEST: " . print_r(wp_remote_get($data->url), true));

    // return
    return $transient;

}

// get plugin info/details
function miGetDetails($result, $action, $args){

    // end case - check action and slug
    if($action !== 'plugin_information' || $args->slug !== PLUGIN_SLUG) return $result;

    // get file remotely
    $remote = wp_remote_get(UPDATE_URL);

    // check errors 
    if(is_wp_error($remote)) return $result;

    // get data
    $data = json_decode(wp_remote_retrieve_body($remote));

    // end case - check for data
    if(!$data) return $result;

    // return obj
    return (object)[

        // Required core fields
        'name'              => 'Met Ice Carousel',
        'slug'              => PLUGIN_SLUG,
        'version'           => $data->version,
        'author'            => $data->author,
        'homepage'          => $data->homepage,
        'download_link'     => $data->url,

        // Required meta
        'requires'          => '5.0',
        'tested'            => '6.8',
        'requires_php'      => '7.4',
        'last_updated'      => date('Y-m-d'),

        // Sections MUST be an array of strings
        'sections' => [
            'description' => $data->description ?? 'No description provided.'
        ],

        // These MUST be objects, not arrays
        'icons'             => (object) [],
        'banners'           => (object) [],
        'banners_rtl'       => (object) [],

        // Optional fields but required by core to exist
        'short_description' => $data->description ?? '',
        'ratings'           => (object) [],
        'support_threads'   => 0,
        'active_installs'   => 1,

    ];

}

// add filter - check for updates
// add_filter('site_transient_update_plugins', "miGetUpdate");
add_filter('pre_set_site_transient_update_plugins', 'miGetUpdate');

// add filter - info popup
add_filter('plugins_api', "miGetDetails", 10, 3);
