<?php
/**
 * Plugin Name: Met Ice Carousel
 * Description: Another Carousel No One Needs
 * Version: 1.0.1
 * Author: Met Ice
 */

define('UPDATE_URL', 'http://localhost/update2.json');
define('PLUGIN_SLUG', 'met-ice-carousel');


// get remote data helper
function miRemoteData(){
    
    // get remote data
    $remote = wp_remote_get(UPDATE_URL);

    // error check
    if(is_wp_error($remote) || wp_remote_retrieve_response_code($remote) !== 200) return false;

    // decode json and return
    return json_decode(wp_remote_retrieve_body($remote));

}


// add common meta
function miMeta(){

    // return array of common meta data
    return [
        'requires'      => '5.0',
        'tested'        => '6.8',
        'requires_php'  => '7.4',
        'icons'         => (object) [],
        'banners'       => (object) [],
        'banners_rtl'   => (object) [],
        'compatibility' => (object) [],
    ];

}

// get/check updates
function miGetUpdate($transient){

    // check transient obj
    if(!is_object($transient)) $transient = new stdClass();
    
    // check transient 
    if(empty($transient->checked)) return $transient;

    // get file
    $file = plugin_basename(__FILE__);

    // get remote data
    $data = miRemoteData();

    // check data and version num
    if(!$data || empty($data->version)) return $transient;

    // get current version
    $currentVersion = $transient->checked[$file] ?? "0";

    // compare previous version to new version
    if(version_compare($currentVersion, $data->version, '<')){
        
        // get common meta
        $meta = miMeta();

        // set transient response obj
        $transient->response[$file] = (object) array_merge([
            
            'id'          => PLUGIN_SLUG,
            'slug'        => PLUGIN_SLUG,
            'plugin'      => $file,
            'name'        => 'Met Ice Carousel',
            'plugin_name' => 'Met Ice Carousel',
            'version'     => $data->version,
            'new_version' => $data->version,
            'url'         => $data->homepage,
            'package'     => $data->url,

        // merge common data
        ], $meta);
    }

    // return transient 
    return $transient;

}

// plugin thickbox info
function miGetDetails($result, $action, $args){

    // check action and slug
    if($action !== 'plugin_information' || $args->slug !== PLUGIN_SLUG) return $result;
    
    // get remote data
    $data = miRemoteData();

    // check data
    if(!$data) return $result;

    // get common meta
    $meta = miMeta();

    // return obj
    return (object) array_merge([
        'name'              => 'Met Ice Carousel',
        'slug'              => PLUGIN_SLUG,
        'version'           => $data->version,
        'author'            => $data->author ?? '',
        'homepage'          => $data->homepage ?? '',
        'download_link'     => $data->url ?? '',
        'last_updated'      => date('Y-m-d'),
        'sections'          => ['description' => $data->description ?? 'No description available.'],
        'short_description' => $data->description ?? '',
        'ratings'           => (object) [],
        'support_threads'   => 0,
        'active_installs'   => 1,

    // merge common data
    ], $meta);
}


// add filters
add_filter('pre_set_site_transient_update_plugins', 'miGetUpdate');
add_filter('plugins_api', 'miGetDetails', 10, 3);
