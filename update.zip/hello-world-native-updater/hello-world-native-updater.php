<?php
/**
 * Plugin Name: Hello World Native Updater
 * Description: A simple plugin with a native WordPress update mechanism.
 * Version: 1.0.0
 * Author: Your Name
 */

// Basic security check to prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// 1. "Hello World" Functionality
// =============================

// Add a menu item to the WordPress admin dashboard
add_action( 'admin_menu', 'hwnu_admin_menu' );

function hwnu_admin_menu() {
    add_menu_page(
        'Hello World Native Updater',
        'Hello World',
        'manage_options',
        'hello-world-native-updater',
        'hwnu_admin_page'
    );
}

// Display the "Hello World" message on the admin page
function hwnu_admin_page() {
    echo '<h1>Hello World!</h1>';
}


// 2. Native Update Functionality
// ==============================

// The URL of our remote JSON file
define( 'HWNU_UPDATE_JSON_URL', 'http://localhost/update2.json' );

// The main plugin file path
define( 'HWNU_PLUGIN_FILE', __FILE__ );

// The plugin's slug (folder_name/file_name.php)
define( 'HWNU_PLUGIN_SLUG', plugin_basename( __FILE__ ) );


/**
 * Check for updates by filtering the update_plugins transient.
 * This is the core of the native update mechanism.
 */
add_filter( 'pre_set_site_transient_update_plugins', 'hwnu_check_for_updates' );

function hwnu_check_for_updates( $transient ) {

    // Check if the transient has a 'checked' property
    if ( empty( $transient->checked ) ) {
        return $transient;
    }

    // Get the installed version of our plugin
    $installed_version = $transient->checked[ HWNU_PLUGIN_SLUG ];

    // Make a request to our remote JSON file
    $response = wp_remote_get( HWNU_UPDATE_JSON_URL );

    if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
        $remote_plugin_data = json_decode( wp_remote_retrieve_body( $response ) );

        // If a new version is available, add it to the transient
        if ( version_compare( $remote_plugin_data->version, $installed_version, '>' ) ) {
            $transient->response[ HWNU_PLUGIN_SLUG ] = (object) [
                'slug'        => 'hello-world-native-updater',
                'plugin'      => HWNU_PLUGIN_SLUG,
                'new_version' => $remote_plugin_data->version,
                'url'         => $remote_plugin_data->homepage,
                'package'     => $remote_plugin_data->download_url,
            ];
        }
    }

    return $transient;
}